
Nama :
1. Baruna Indrakesuma  					(2014150119)
----------------------------------------------------------------
- Instal Laravel: `composer install --prefer-dist`
- Migrasikan database: `php artisan migrate`
- Ketikan Perintah: `php artisan db: seed`
- Lihat aplikasi di browser.
